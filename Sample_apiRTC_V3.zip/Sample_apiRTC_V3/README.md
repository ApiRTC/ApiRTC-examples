<a href="https://www.apirtc.com"><img src="https://apirtc.com/wp-content/uploads/2018/09/ApiRTC_relook_branding_v01.png" width="260"></a>

# ApiRTC V3

This directory contains usage example of [ApiRTC](http://www.apirtc.com).

These sample are based on apiRTC V3 : API of ApiRTC V3 are also maintained in order to keep compatibility with existing applications but we advice using apiRTC V4 has it offers a simplified API for integration.


